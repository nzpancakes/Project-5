
public class Savings extends Account
{
	private double interestRate;
	
	//--------------------------------------------------------------------------------------------------------------
	//Constructor
				
	Savings(int accountNumberInstance,double interestRateInstance) 
	{
		super(accountNumberInstance);
		interestRate = interestRateInstance;
		accountType = "s";
	}

	//--------------------------------------------------------------------------------------------------------------
	//Setters
					 
	public void setInterestRate(double n) 
	{
		interestRate = n;
		if (interestRate <= 0) 
		{
			interestRate = 0;
		}
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable getters
					
	public double getInterestRate() 
	{
		return interestRate;
	}
	
	//--------------------------------------------------------------------------------------------------------------
	//Override methods
	
	@Override
	public double computeInterest(double interestPeriod)
	{
		double interest = ((Math.pow((1 + interestRate),interestPeriod))* getAccountBalance()) - getAccountBalance() ;
		return interest;
	}
	
	public String toString(int accountNumber) 
	{
		return "Savings Account # = " + accountNumber + "\n" + "Savings Balance = " + accountBalance + "\n" + "Savings Interest Rate = " + (interestRate * 100) + "%";
	}
	
}
