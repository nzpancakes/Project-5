import java.lang.String;

public class Account 
{
	protected int accountNumber;
	protected double accountBalance;
	protected String accountType;
	
	//--------------------------------------------------------------------------------------------------------------
	//Constructor
		
	Account(int accountNumberInstance) 

	{
		accountNumber = accountNumberInstance;
		accountBalance = 0;
			
	}
		
	//--------------------------------------------------------------------------------------------------------------
	//Setters
				 
	public void setAccountBalance(double n) 
	{
		accountBalance = n;
	}
				
	public void setAccountNumber(int n) 
	{
		accountNumber = n;
	}
	
	public void setaccountType(String n) 
	{
		accountType = n;
	}
				
	//--------------------------------------------------------------------------------------------------------------
	//Instance variable getters
				
	public double getAccountBalance() 
	{
		return accountBalance;
	}
				
	public int getAccountNumber() 
	{
		return accountNumber;
	}
	
	public String getaccountType() 
	{
		return accountType;
	}
	//--------------------------------------------------------------------------------------------------------------
	//Methods
	
	public String toString(int accountNumber) 
	{
		return "Account # = " + accountNumber + " Account Balance = " + accountBalance;
	}
	
	public void deposit(double depositAmount) 
	{
		
		accountBalance = accountBalance + depositAmount;
		setAccountBalance(accountBalance);
		
	}
	
	public void withdraw(double withdrawAmount) 
	{
		if ((accountBalance - withdrawAmount) <= 0) 
		{
			System.out.println("You do not have that much in this account.");
		}
		
		else 
		{
			accountBalance = accountBalance - withdrawAmount;
			setAccountBalance(accountBalance);
		}
		
	
	}
	
	public double computeInterest(double interestPeriod) 
	{
		double interest = 0;
		return interest;
	}
	

}
