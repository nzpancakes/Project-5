/**
 * Assignment 5: This class drives the program, asking for initial input values balance and account number amount 
 * Issues: N/A
 * @author 
 * @version 1.0
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
	private static final double INTEREST_RATE = .02;
	ArrayList<Savings> savingsList = new ArrayList<Savings>();
	ArrayList<Checking> checkingList = new ArrayList<Checking>();
	

		public static void main(String[] args) 
		{
			Scanner input = new Scanner (System.in);
			//--------------------------------------------------------------------------------------------------------------
			// initializing variables
			
			int firstChoice = 6;
			int len = 0;
			int accountNumber = 0;
			double interestPeriod;
			Bank bankObject = new Bank();
			Account accountObject = new Account(0);
			//--------------------------------------------------------------------------------------------------------------
			// initializing variables end
		
			while (firstChoice != 0)
			{
				System.out.println("====================");
				System.out.println("Enter 1 to enter account amount, 2 to check an individual account, 3 to display all accounts information, 4 to display all Savings accounts, 5 to display all Checking accounts, 6 to add a new account, 7 to remove an account, or 8 to exit : ");
				firstChoice = input.nextInt();
				System.out.println("====================");
			
				if (firstChoice == 1)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option auto-generates accounts
				
					System.out.println("How many accounts would you like to create?");
					len = input.nextInt();
					bankObject.initSavingsList(len);
				}
			
				else if (firstChoice == 2)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option allows the user to check a single account and perform deposits or withdraws
					System.out.println("Enter the account number that you would like to access: ");
					accountNumber = input.nextInt();
					int accountIndex = 0; 
				
					//--------------------------------------------------------------------------------------------------------------
					//getting the index value of the account in the array list
				
					accountIndex = bankObject.findAccountNumber(accountNumber);
				
					//--------------------------------------------------------------------------------------------------------------
					//displaying current balance of account
					if (accountNumber % 2 == 0) 
					{
						//Savings savingsObject = new Savings(0,0);
						//savingsObject.setAccountBalance();
						System.out.println(bankObject.savingsList.get(accountIndex).toString(accountNumber));
						
					}
					
					else 
					{
						System.out.println(bankObject.checkingList.get(accountIndex).toString(accountNumber));
					}
				
				
				}
			
				else if (firstChoice == 3)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all account information
				
				}
			
				else if (firstChoice == 4)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all Savings account information
				
				}
			
				else if (firstChoice == 5)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option displays all Checking account information
				
				}
			
				else if (firstChoice == 6)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option allows the user to add a new account
				
				}
			
				else if (firstChoice == 7)
				{
					//--------------------------------------------------------------------------------------------------------------
					// This option allows the user to remove an account
				
				}
				//--------------------------------------------------------------------------------------------------------------
				// Option to exit program
			
				else if (firstChoice == 8)
				{
					System.out.println("");
					System.out.println("Exiting program");
					input.close();
					System.exit(0);
				}
			
				//--------------------------------------------------------------------------------------------------------------
				// Error catching for random input choice
			
				else if ((firstChoice != 1) & (firstChoice != 2) & (firstChoice != 3) & (firstChoice != 4) & (firstChoice != 5) & (firstChoice != 6) & (firstChoice != 7) & (firstChoice != 8))
				{
					System.out.println("Use option 1 to enter an amount of accounts first or select a valid option");
					System.out.println("====================");
					System.out.println("");
				}
			}
		}
		public int findAccountNumber(int accountNumber) 
		{
			int z = 0;
			int y = -1;
			
			if (accountNumber % 2 == 0) 
			{
				for(int x = 0;((y != accountNumber) & (x < savingsList.size()));x++) 
				{
					// gets account number from array
					y = savingsList.get(x).getAccountNumber();
					
					// sets z to index of account number
					z = x;
					
					
				}
			}
			
			else
			{
				for(int x = 0;((y != accountNumber) & (x < checkingList.size()));x++) 
				{
					// gets account number from array
					y = checkingList.get(x).getAccountNumber();
					
					// sets z to index of account number
					z = x;
					
				}
			}
			
			
			return z;
		}
		
		public void initSavingsList(int n) 
		{
			double y = 50;
			int x = 101;
			int z;
		
			for (x = 0; x <= n; x++) 
			{
				//--------------------------------------------------------------------------------------------------------------
				// Calculating balance based off number of accounts
				z = 101 + x;	
				y = z * 50;
				
				//--------------------------------------------------------------------------------------------------------------
				//Checking if even or odd account number
				
				if (z % 2 == 0)
				{
					//--------------------------------------------------------------------------------------------------------------
					// Creating a new savings object storing the account number and balance
					Savings savingsObject = new Savings(z,y);
					
					
					//--------------------------------------------------------------------------------------------------------------
					// Adding account to the savings array
					savingsList.add(savingsObject);
					
					
				}
				
				else 
				{
					//--------------------------------------------------------------------------------------------------------------
					// Creating a new checking object storing the account number and balance
					Checking checkingObject = new Checking(z,y);
					
					//--------------------------------------------------------------------------------------------------------------
					// Adding account to the checking array
					checkingList.add(checkingObject);
					
				}
				
				
			}
		}
}
